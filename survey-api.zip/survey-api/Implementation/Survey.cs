﻿#region "Namespace"
using SurveyCoreAPI.Abstraction;
using SurveyCoreAPI.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.IO;
using Microsoft.Extensions.Logging;
#endregion "Namespace"

namespace SurveyCoreAPI.Implementation
{
    public class Survey : ISurvey
    {
        #region "Members"
        
        private readonly ILogger _logger;
        string serveyPath = @"E:\WORKSPACE\.NET Core\SurveyCoreAPI\Data\Survey.json";
        string serveyResultPath = @"E:\WORKSPACE\.NET Core\SurveyCoreAPI\Data\SurveyResults.json";
        #endregion "Members"

        #region "Public Methods"

        public Survey(ILogger<Survey> logger)
        {
            _logger = logger;
        }

        public bool CreateSurvey(SurveyModel surveyModel)
        {
            try
            {                            
                string jsondata = JsonConvert.SerializeObject(surveyModel);              
                File.WriteAllText(serveyPath, jsondata);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return false ;
            }
        }

        public List<SurveyModel> GetSurveys()
        {
            try
            {
                var jsonString = File.ReadAllText(serveyPath);
                var jsonSurveys = JsonConvert.DeserializeObject<List<SurveyModel>>(jsonString);
                var surveys = jsonSurveys.Select(s => new SurveyModel
                {
                    SurveyId = s.SurveyId,
                    Name = s.Name
                }).ToList();
                return surveys;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return null;
            }
        }

        public SurveyModel PullSurvey(int surveyId)
        {
            try
            {
                var jsonString = File.ReadAllText(serveyPath);
                var jsonSurveys = JsonConvert.DeserializeObject<List<SurveyModel>>(jsonString);
                var surveys = jsonSurveys.Where(i => i.SurveyId == surveyId).Select(s => new SurveyModel
                {
                    SurveyId = s.SurveyId,
                    Name = s.Name,
                    Questions = s.Questions.Select(q => new Question { QuestionId=q.QuestionId, QuestionName=q.QuestionName, Option=q.Option}).ToList()                    
                }).FirstOrDefault();
                return surveys;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return null;
            }
        }

        public bool SendSurveyInvite(string username)
        {
            try
            {
                //Sent Email to User with survey link
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return false;
            }
        }

        public bool SubmitSurvey(SurveyResults surveyResults)
        {
            try
            {
                string jsondata = JsonConvert.SerializeObject(surveyResults);
                File.WriteAllText(serveyResultPath, jsondata);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return false;
            }
        }

        public SurveyModel SurveyResult(int surveyId)
        {
            try
            {
                var jsonString = File.ReadAllText(serveyResultPath);
                var jsonSurveyResults = JsonConvert.DeserializeObject<List<SurveyResults>>(jsonString);
                var surveyResults = jsonSurveyResults.Where(i => i.SurveyId == surveyId).FirstOrDefault()?.SurveyAnswers;

                var jsonSurveyString = File.ReadAllText(serveyPath);
                var jsonSurveys = JsonConvert.DeserializeObject<List<SurveyModel>>(jsonSurveyString);

                var surveys = jsonSurveys.Where(i => i.SurveyId == surveyId).Select(s => new SurveyModel
                {
                    SurveyId = s.SurveyId,
                    Name = s.Name,
                    Questions = s.Questions.Select(q => 
                    new Question 
                    {
                        QuestionId = q.QuestionId,
                        QuestionName = q.QuestionName,
                        Answer = surveyResults.Where(a=>a.QuestionId == q.QuestionId).FirstOrDefault().Answer
                    }).ToList()
                }).FirstOrDefault();

                return surveys;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return null;
            }
        }

        #endregion "Public Methods"
    }
}
