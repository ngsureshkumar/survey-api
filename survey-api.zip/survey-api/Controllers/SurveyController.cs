﻿#region "Namespace"
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SurveyCoreAPI.Abstraction;
using SurveyCoreAPI.Model;
using Microsoft.Extensions.Logging;
#endregion "Namespace"

namespace SurveyCoreAPI.Controllers
{
    [Route("api/survey")]
    public class SurveyController : Controller
    {
        #region "Members"

        private readonly ISurvey _iSurvey;
        private readonly ILogger _logger;

        #endregion "Members"

        #region "Public Methods"

        public SurveyController(ISurvey iSurvey,ILogger<SurveyController> logger)
        {
            _iSurvey = iSurvey;
            _logger = logger;
        }

        [HttpPost("createsurvey")]
        public IActionResult CreateSurvey([FromBody]SurveyModel surveyModel)
        {
            var response =_iSurvey.CreateSurvey(surveyModel);
            _logger.LogInformation("Survey has been created successfully!!");
            return  Json(response);
        }

        [HttpGet("sendsurveyinvite")]
        public IActionResult SendSurveyInvite(string username)
        {
            var response = _iSurvey.SendSurveyInvite(username);
            _logger.LogInformation("Survey Invite has been sent successfully!!");
            return Json(response);
        }

        [HttpGet("pullsurvey")]
        public IActionResult PullSurvey(int surveyId)
        {
            var response = _iSurvey.PullSurvey(surveyId);
            return Json(response);
        }

        [HttpPost("submitsurvey")]
        public IActionResult SubmitSurvey([FromBody]SurveyResults surveyResults )
        {
            var response = _iSurvey.SubmitSurvey(surveyResults);
            _logger.LogInformation("Survey has been submitted successfully!!");
            return Json(response);
        }

        [HttpGet("surveyresult")]
        public IActionResult SurveyResult(int surveyId)
        {
            var response =  _iSurvey.SurveyResult(surveyId);
            return Json(response);
        }

        #endregion "Public Methods"
    }
}
